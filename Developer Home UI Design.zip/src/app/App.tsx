import { useState } from "react";

// ── Brand tokens ──────────────────────────────────────────────────────────────
const C = {
  amber:     "#F5A623",
  navBg:     "#0D5C73",
  teal:      "#00B4CC",
  tealDark:  "#0A9BB0",
  tealBg:    "#E6F8FA",
  contentBg: "#F0F2F5",
  heading:   "#0D3D4F",
  bodyGrey:  "#6B7A85",
};

// ── Tour step definitions ────────────────────────────────────────────────────
const TOUR_STEPS = [
  {
    title: "API Credentials",
    desc:  "Your sandbox Public and Secret API keys live here. Copy them to authenticate every API request.",
    h:   { top: 322, left: 196, w: 603, ht: 190 },
    tip: { top: 524, left: 206, side: "top" as const },
  },
  {
    title: "Developer Section",
    desc:  "The sidebar Developer section holds your API Keys, Developer Settings, and full API Documentation.",
    h:   { top: 392, left: 0, w: 174, ht: 144 },
    tip: { top: 395, left: 192, side: "left" as const },
  },
  {
    title: "Transactions",
    desc:  "Every test payment triggered via the API appears here. Search, filter, and inspect full details.",
    h:   { top: 128, left: 0, w: 174, ht: 44 },
    tip: { top: 126, left: 192, side: "left" as const },
  },
  {
    title: "Ask Navi",
    desc:  "Navi is your AI assistant. Ask it about endpoints, authentication flows, error codes, or anything integration-related.",
    h:   { top: 36, left: 1082, w: 200, ht: 56 },
    tip: { top: 104, left: 882, side: "top" as const },
  },
  {
    title: "Quick Start Guide",
    desc:  "Follow the step-by-step checklist to go from setup to your first successful test transaction.",
    h:   { top: 322, left: 817, w: 603, ht: 190 },
    tip: { top: 524, left: 637, side: "top" as const },
  },
];

// ═════════════════════════════════════════════════════════════════════════════
// ENTRY SCREEN  (replicated from ABA PayWay sandbox screenshot)
// ═════════════════════════════════════════════════════════════════════════════

function EntryScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        fontFamily:      "'Inter', sans-serif",
        backgroundColor: "#EBEBEB",
        position:        "relative",
        overflow:        "hidden",
      }}
    >
      {/* PayWay background watermark */}
      <div
        aria-hidden
        style={{
          position:   "absolute",
          inset:      0,
          display:    "flex",
          alignItems: "center",
          justifyContent: "center",
          pointerEvents: "none",
          zIndex: 0,
        }}
      >
        <WatermarkPattern />
      </div>

      {/* ABA+ PayWay logo — top left */}
      <div className="relative z-10 px-8 py-5">
        <div className="flex items-center">
          <span className="font-extrabold text-xl leading-none" style={{ color: "#E8352A" }}>ABA</span>
          <sup className="font-black text-white ml-0.5" style={{ fontSize: 9, color: "#E8352A" }}>+</sup>
          <span
            className="font-extrabold italic ml-1"
            style={{ fontSize: 20, color: C.teal, letterSpacing: "0.03em" }}
          >
            PAYWAY
          </span>
        </div>
      </div>

      {/* Centered card */}
      <div className="flex-1 flex items-center justify-center relative z-10 px-6 pb-8">
        <div
          className="flex overflow-hidden"
          style={{
            borderRadius: 16,
            boxShadow:    "0 8px 40px rgba(0,0,0,0.13)",
            width:        680,
          }}
        >
          {/* Left panel — warm dark bg + 3-D cube */}
          <div
            className="flex items-center justify-center"
            style={{
              width:           280,
              background:      "linear-gradient(145deg, #C8A96A 0%, #D4A843 40%, #B8913A 100%)",
              minHeight:       320,
              position:        "relative",
            }}
          >
            {/* Ambient glow */}
            <div style={{
              position: "absolute", inset: 0,
              background: "radial-gradient(ellipse at 50% 60%, rgba(255,220,120,0.22) 0%, transparent 70%)",
            }} />
            <GoldenCube />
          </div>

          {/* Right panel — white content */}
          <div className="flex-1 bg-white flex flex-col items-center justify-center px-10 py-10 relative">
            {/* EN badge */}
            <div
              className="absolute top-4 right-4 flex items-center gap-1 text-xs text-gray-400 border border-gray-200 rounded-full px-2 py-0.5"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/>
                <path d="M12 2a15.3 15.3 0 010 20M12 2a15.3 15.3 0 000 20"/>
              </svg>
              EN
            </div>

            {/* Success icon with sparkles */}
            <div className="relative mb-5">
              <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: "#22C55E" }}>
                <svg width="28" height="24" fill="none" stroke="white" strokeWidth="3" viewBox="0 0 28 24">
                  <polyline points="3,13 10,20 25,4" />
                </svg>
              </div>
              {/* Sparkle dots */}
              <div className="absolute -top-2 -right-2 w-3 h-3 rounded-full" style={{ backgroundColor: C.teal }} />
              <div className="absolute top-1 -right-5 w-2 h-2 rounded-full" style={{ backgroundColor: C.teal, opacity: 0.5 }} />
              <div className="absolute -top-3 right-2 w-1.5 h-1.5 rounded-full" style={{ backgroundColor: C.teal, opacity: 0.4 }} />
              <div className="absolute -bottom-2 -left-3 w-2.5 h-2.5 rounded-full" style={{ backgroundColor: "#B8E8F0", opacity: 0.8 }} />
            </div>

            <h2 className="text-xl font-bold mb-2 text-center" style={{ color: C.heading }}>
              Account Created
            </h2>
            <p className="text-sm text-center leading-relaxed mb-7" style={{ color: C.bodyGrey, maxWidth: 240 }}>
              Your ABA PayWay Sandbox account is ready! Start simulating transactions in a secure, risk-free environment now.
            </p>

            <button
              onClick={onEnter}
              className="w-full rounded-lg py-2.5 text-sm font-semibold text-white transition-colors"
              style={{ backgroundColor: C.teal, maxWidth: 240 }}
              onMouseEnter={e => ((e.currentTarget as HTMLElement).style.backgroundColor = C.tealDark)}
              onMouseLeave={e => ((e.currentTarget as HTMLElement).style.backgroundColor = C.teal)}
            >
              Go to Sandbox
            </button>
          </div>
        </div>
      </div>

      {/* ABA Bank footer */}
      <div className="relative z-10 pb-5 px-8 flex items-end gap-4">
        <div className="flex items-center gap-2">
          <div className="h-7 px-2 bg-gray-800 rounded flex items-center">
            <span className="text-white font-bold text-xs">ABA BANK</span>
          </div>
          <div className="h-7 px-2 bg-red-700 rounded flex items-center">
            <span className="text-white font-bold" style={{ fontSize: 9 }}>NATIONAL BANK OF CAMBODIA</span>
          </div>
        </div>
        <div className="flex flex-col gap-0.5">
          <p className="text-xs text-gray-500">
            Advanced Bank of Asia Ltd. 148 Preah Sihanouk Blvd, Sangkat Boeung Keng Kang I, Khan Boeung Keng Kang, Phnom Penh, Cambodia
          </p>
          <a href="#" className="text-xs" style={{ color: C.teal }}>Privacy Policy</a>
        </div>
        <div className="ml-auto flex items-center gap-2.5">
          {/* Facebook */}
          <a href="#" className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: "#E5E7EB" }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="#4B5563"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
          </a>
          {/* YouTube */}
          <a href="#" className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: "#E5E7EB" }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="#4B5563"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 001.46 6.42 29 29 0 001 12a29 29 0 00.46 5.58 2.78 2.78 0 001.95 1.95C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 001.95-1.96A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon fill="white" points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/></svg>
          </a>
          {/* LinkedIn */}
          <a href="#" className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: "#E5E7EB" }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="#4B5563"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>
          </a>
        </div>
      </div>
    </div>
  );
}

// 3-D isometric golden cube (SVG)
function GoldenCube() {
  return (
    <svg width="140" height="140" viewBox="0 0 140 140" fill="none">
      {/* Top face */}
      <polygon points="70,20 120,47 70,74 20,47" fill="#F5C842" />
      {/* Left face */}
      <polygon points="20,47 70,74 70,120 20,93" fill="#C8903A" />
      {/* Right face */}
      <polygon points="120,47 70,74 70,120 120,93" fill="#E8A830" />
      {/* Subtle edge highlight on top */}
      <polygon points="70,20 120,47 70,74 20,47" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="1" />
    </svg>
  );
}

// Repeating PayWay watermark background
function WatermarkPattern() {
  return (
    <svg width="1200" height="800" viewBox="0 0 1200 800" fill="none" style={{ opacity: 0.045 }}>
      {[0, 1, 2, 3, 4].map(row =>
        [0, 1, 2].map(col => (
          <text
            key={`${row}-${col}`}
            x={col * 420 - 60}
            y={row * 180 + 120}
            fontSize="80"
            fontWeight="900"
            fontStyle="italic"
            fill="#0D5C73"
            fontFamily="Arial, sans-serif"
            transform={`rotate(-20, ${col * 420 + 150}, ${row * 180 + 80})`}
          >
            PAYWAY
          </text>
        ))
      )}
    </svg>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// WELCOME MODAL  (Paystack-style — minimal, centered, single CTA)
// ═════════════════════════════════════════════════════════════════════════════

function WelcomeModal({ onDismiss, onTour }: { onDismiss: () => void; onTour: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ backgroundColor: "rgba(0,0,0,0.45)" }}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl text-center flex flex-col items-center"
        style={{ width: 400, padding: "36px 40px 32px" }}
      >
        {/* Close */}
        <button
          onClick={onDismiss}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 text-xl leading-none"
          style={{ position: "absolute" }}
        >
          ×
        </button>

        {/* PayWay icon mark */}
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
          style={{ background: `linear-gradient(135deg, ${C.teal} 0%, #0A9BB0 100%)` }}
        >
          <svg width="28" height="28" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24">
            <rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>
            <line x1="6" y1="15" x2="9" y2="15"/><line x1="11" y1="15" x2="14" y2="15"/>
          </svg>
        </div>

        <p className="text-xs font-semibold uppercase tracking-widest mb-1" style={{ color: C.teal }}>
          ABA PayWay Sandbox
        </p>
        <h2 className="text-lg font-bold mb-3" style={{ color: C.heading }}>
          Welcome, Henry! 👋
        </h2>
        <p className="text-sm leading-relaxed mb-7" style={{ color: C.bodyGrey, maxWidth: 300 }}>
          Your sandbox is in test mode so you can start integrating right away. No real money moves — everything here is safe to explore.
        </p>

        <button
          onClick={onDismiss}
          className="w-full rounded-lg py-3 text-sm font-semibold text-white mb-3"
          style={{ backgroundColor: C.teal }}
          onMouseEnter={e => ((e.currentTarget as HTMLElement).style.backgroundColor = C.tealDark)}
          onMouseLeave={e => ((e.currentTarget as HTMLElement).style.backgroundColor = C.teal)}
        >
          Got it, let&apos;s go!
        </button>
        <button
          onClick={onTour}
          className="text-xs font-medium"
          style={{ color: C.teal }}
        >
          Take a guided tour of the dashboard →
        </button>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// TOUR OVERLAY
// ═════════════════════════════════════════════════════════════════════════════

function TourOverlay({ step, total, onNext, onPrev, onSkip }: {
  step: number; total: number;
  onNext: () => void; onPrev: () => void; onSkip: () => void;
}) {
  const s = TOUR_STEPS[step];
  const isLast = step === total - 1;

  return (
    <div className="fixed inset-0 z-40" style={{ pointerEvents: "none" }}>
      {/* Spotlight */}
      <div
        className="absolute rounded-lg transition-all duration-300"
        style={{
          top:       s.h.top,
          left:      s.h.left,
          width:     s.h.w,
          height:    s.h.ht,
          boxShadow: "0 0 0 9999px rgba(8,40,55,0.70)",
          border:    `2px solid ${C.teal}`,
          zIndex:    1,
        }}
      />
      {/* Tooltip */}
      <div
        className="absolute rounded-xl shadow-2xl p-5"
        style={{
          top:             s.tip.top,
          left:            s.tip.left,
          width:           288,
          backgroundColor: "#fff",
          zIndex:          2,
          pointerEvents:   "all",
          border:          `1px solid ${C.tealBg}`,
        }}
      >
        {s.tip.side === "top" && (
          <div className="absolute -top-2.5 left-8 w-4 h-4 bg-white rotate-45 border-t border-l" style={{ borderColor: C.tealBg }} />
        )}
        {s.tip.side === "left" && (
          <div className="absolute top-4 -left-2.5 w-4 h-4 bg-white rotate-45 border-b border-l" style={{ borderColor: C.tealBg }} />
        )}

        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: C.teal }}>
            Step {step + 1} of {total}
          </span>
          <button onClick={onSkip} className="text-xs text-gray-400 hover:text-gray-600">Skip tour</button>
        </div>

        <div className="flex gap-1.5 mb-3">
          {Array.from({ length: total }).map((_, i) => (
            <div key={i} className="h-1 rounded-full flex-1 transition-colors"
              style={{ backgroundColor: i <= step ? C.teal : "#E5E7EB" }} />
          ))}
        </div>

        <h3 className="font-semibold text-sm mb-1" style={{ color: C.heading }}>{s.title}</h3>
        <p className="text-xs text-gray-500 leading-relaxed mb-4">{s.desc}</p>

        <div className="flex items-center gap-2">
          {step > 0 && (
            <button onClick={onPrev} className="text-xs font-medium px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50">
              Back
            </button>
          )}
          <button
            onClick={onNext}
            className="flex-1 text-xs font-semibold py-1.5 rounded-lg text-white"
            style={{ backgroundColor: C.teal }}
          >
            {isLast ? "Finish Tour ✓" : "Next →"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// CREATE TRANSACTION MODAL
// ═════════════════════════════════════════════════════════════════════════════

function CreateTransactionModal({ onClose }: { onClose: () => void }) {
  const [amount,   setAmount]   = useState("10.00");
  const [currency, setCurrency] = useState("USD");
  const [desc,     setDesc]     = useState("Test payment from sandbox");
  const [success,  setSuccess]  = useState(false);
  const [loading,  setLoading]  = useState(false);

  const run = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setSuccess(true); }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ backgroundColor: "rgba(13,61,79,0.6)" }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        <div className="h-1 w-full" style={{ background: `linear-gradient(90deg, ${C.teal}, #4DDAEC)` }} />
        {success ? (
          <div className="px-8 py-10 flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: "#ECFDF5" }}>
              <svg width="28" height="24" fill="none" stroke="#22C55E" strokeWidth="2.5" viewBox="0 0 28 24">
                <polyline points="3,13 9,19 25,4" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold mb-1" style={{ color: C.heading }}>Transaction Successful!</h3>
            <p className="text-sm text-gray-500 mb-2">Your test payment was processed.</p>
            <div className="text-xs font-mono bg-gray-50 border border-gray-100 rounded-lg px-4 py-2 mb-6 w-full text-center" style={{ color: C.teal }}>
              txn_sandbox_7f3a2b1c9d · {currency} {parseFloat(amount).toFixed(2)}
            </div>
            <div className="flex gap-3 w-full">
              <button onClick={onClose} className="flex-1 text-sm font-semibold py-2.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50">Close</button>
              <button className="flex-1 text-sm font-semibold py-2.5 rounded-lg text-white" style={{ backgroundColor: C.teal }}>View in Transactions</button>
            </div>
          </div>
        ) : (
          <div className="px-8 py-7">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-semibold text-base" style={{ color: C.heading }}>Create Test Transaction</h3>
                <p className="text-xs text-gray-400 mt-0.5">Simulate a payment using sandbox credentials</p>
              </div>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">×</button>
            </div>
            <form onSubmit={run} className="flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Amount</label>
                  <input type="number" value={amount} onChange={e => setAmount(e.target.value)} step="0.01"
                    className="border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none"
                    style={{ backgroundColor: "#FAFAFA" }}
                    onFocus={e => (e.target.style.borderColor = C.teal)}
                    onBlur={e => (e.target.style.borderColor = "#E5E7EB")} />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Currency</label>
                  <select value={currency} onChange={e => setCurrency(e.target.value)}
                    className="border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none"
                    style={{ backgroundColor: "#FAFAFA" }}>
                    <option value="USD">USD</option>
                    <option value="KHR">KHR</option>
                  </select>
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</label>
                <input type="text" value={desc} onChange={e => setDesc(e.target.value)}
                  className="border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none"
                  style={{ backgroundColor: "#FAFAFA" }}
                  onFocus={e => (e.target.style.borderColor = C.teal)}
                  onBlur={e => (e.target.style.borderColor = "#E5E7EB")} />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Test Card</label>
                <div className="border border-gray-100 rounded-lg px-3 py-2.5 bg-gray-50 flex items-center justify-between">
                  <span className="text-sm font-mono text-gray-500">4111 1111 1111 1111</span>
                  <span className="text-xs text-gray-400">12/28 · 123</span>
                </div>
              </div>
              <button type="submit" disabled={loading}
                className="w-full rounded-lg py-3 text-sm font-semibold text-white mt-1"
                style={{ backgroundColor: loading ? "#7DC8D8" : C.teal }}>
                {loading ? "Processing…" : "Run Test Transaction"}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// SHARED CHROME
// ═════════════════════════════════════════════════════════════════════════════

function SandboxBanner() {
  return (
    <div className="flex items-center justify-between px-6 py-2 shrink-0" style={{ backgroundColor: C.amber }}>
      <div className="w-36" />
      <div className="flex items-center gap-2 text-white text-sm font-medium">
        <svg width="14" height="14" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24">
          <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
        </svg>
        Sandbox Mode
      </div>
      <div className="w-36 flex justify-end">
        <button className="flex items-center gap-1.5 border border-white/70 text-white text-xs px-3 py-1 rounded-full hover:bg-white/10 transition-colors">
          <span className="text-xs leading-none">⊕</span> APIs &amp; Docs
        </button>
      </div>
    </div>
  );
}

function PayWayLogo() {
  return (
    <div className="flex items-center">
      <span className="font-extrabold text-base leading-none" style={{ color: "#E8352A" }}>ABA</span>
      <sup className="font-black ml-0.5 text-white" style={{ fontSize: 8 }}>+</sup>
      <span className="font-extrabold italic text-white ml-1 tracking-wide" style={{ fontSize: 17, letterSpacing: "0.03em" }}>
        PAYWAY
      </span>
    </div>
  );
}

function TopNav() {
  return (
    <div className="flex items-center justify-between px-5 h-14 shrink-0" style={{ backgroundColor: C.navBg }}>
      <div className="flex items-center gap-3">
        <button className="text-white/70 hover:text-white">
          <svg width="18" height="14" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="0" y1="1" x2="18" y2="1"/><line x1="0" y1="7" x2="18" y2="7"/><line x1="0" y1="13" x2="18" y2="13"/>
          </svg>
        </button>
        <PayWayLogo />
      </div>
      <div className="flex items-center gap-4">
        <button className="flex items-center gap-2 text-white text-sm font-medium px-4 py-1.5 rounded-full"
          style={{ background: "linear-gradient(135deg, #A855F7 0%, #7C3AED 100%)" }}>
          <span style={{ fontSize: 13 }}>✦</span> Ask Navi
        </button>
        <button className="text-white/70 hover:text-white">
          <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="3"/>
            <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/>
          </svg>
        </button>
        <div className="flex items-center gap-2 text-white cursor-pointer">
          <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: "#1A7A90" }}>
            <svg width="15" height="15" fill="none" stroke="white" strokeWidth="1.8" viewBox="0 0 24 24">
              <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
            </svg>
          </div>
          <div className="text-xs leading-tight">
            <div className="font-semibold">Olakunle Henry</div>
            <div className="opacity-60 text-xs">Super Admin</div>
          </div>
          <svg width="12" height="12" fill="none" stroke="white" strokeWidth="2" viewBox="0 0 24 24" className="opacity-60">
            <polyline points="6 9 12 15 18 9"/>
          </svg>
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// SIDEBAR  (Stripe-inspired grouping with Developer section)
// ═════════════════════════════════════════════════════════════════════════════

const NAV_MAIN = [
  { label: "Home",              icon: "home",  active: true  },
  { label: "Transactions",      icon: "swap",  active: false },
  { label: "Invoices",          icon: "file",  active: false },
  { label: "Customers",         icon: "user",  active: false },
  { label: "Discount Programs", icon: "tag",   active: false },
  { label: "Payment Link",      icon: "link",  active: false },
];

const NAV_DEV = [
  { label: "API Keys",           icon: "key"     },
  { label: "Developer Settings", icon: "sliders" },
  { label: "API Documentation",  icon: "book"    },
];

function Sidebar({ devOpen, setDevOpen }: { devOpen: boolean; setDevOpen: (v: boolean) => void }) {
  return (
    <aside className="w-44 bg-white border-r border-gray-100 flex flex-col py-3 shrink-0 overflow-y-auto">
      <nav className="flex flex-col gap-0.5 px-2">
        {NAV_MAIN.map(({ label, icon, active }) => (
          <NavItem key={label} label={label} icon={icon} active={active} />
        ))}

        {/* Stripe-style section separator + label */}
        <div className="mt-3 px-3 pb-1">
          <div className="h-px bg-gray-100 mb-3" />
          {/* Developer section header */}
          <button
            onClick={() => setDevOpen(!devOpen)}
            className="flex items-center justify-between w-full group"
          >
            <div className="flex items-center gap-1.5">
              <svg width="12" height="12" fill="none" stroke="#94A3B8" strokeWidth="2.2" viewBox="0 0 24 24">
                <polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>
              </svg>
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "#94A3B8", letterSpacing: "0.1em" }}>
                Developer
              </span>
            </div>
            <svg
              width="11" height="11" fill="none" stroke="#CBD5E1" strokeWidth="2" viewBox="0 0 24 24"
              style={{ transform: devOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }}
            >
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>
        </div>

        {devOpen && (
          <div className="flex flex-col gap-0.5 mt-0.5">
            {NAV_DEV.map(({ label, icon }) => (
              <NavItem key={label} label={label} icon={icon} active={false} sub />
            ))}
          </div>
        )}
      </nav>

      {/* Sidebar footer */}
      <div className="mt-auto px-4 pb-4 pt-4">
        <div className="border-t border-gray-100 pt-3">
          <div className="text-xs text-gray-400 mb-1.5">Last login:</div>
          <div className="flex items-center gap-1 mb-2">
            <div className="h-4 w-8 rounded-sm bg-gray-800 flex items-center justify-center">
              <span className="text-white font-bold" style={{ fontSize: 6 }}>ABA</span>
            </div>
            <div className="h-4 w-6 rounded-sm bg-red-700 flex items-center justify-center">
              <span className="text-white font-bold" style={{ fontSize: 5 }}>NBC</span>
            </div>
          </div>
          <div className="text-xs text-gray-400 leading-tight">PayWay Portal V2.0</div>
          <div className="flex gap-1.5 mt-1.5">
            <a href="#" className="text-xs" style={{ color: C.teal }}>Privacy</a>
            <span className="text-xs text-gray-300">|</span>
            <a href="#" className="text-xs" style={{ color: C.teal }}>Terms</a>
          </div>
        </div>
      </div>
    </aside>
  );
}

function NavItem({ label, icon, active, sub }: { label: string; icon: string; active?: boolean; sub?: boolean }) {
  return (
    <a
      href="#"
      className="flex items-center gap-2.5 rounded text-sm font-medium transition-colors"
      style={{
        padding:         sub ? "7px 12px 7px 20px" : "10px 12px",
        color:           active ? C.teal : "#5A6E7A",
        backgroundColor: active ? C.tealBg : "transparent",
        borderLeft:      active ? `3px solid ${C.teal}` : "3px solid transparent",
      }}
      onMouseEnter={e => { if (!active) (e.currentTarget as HTMLElement).style.backgroundColor = "#F5F7F8"; }}
      onMouseLeave={e => { if (!active) (e.currentTarget as HTMLElement).style.backgroundColor = "transparent"; }}
    >
      <NavIcon name={icon} active={!!active} />
      <span style={{ fontSize: sub ? 12 : 14 }}>{label}</span>
    </a>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// DASHBOARD CONTENT
// ═════════════════════════════════════════════════════════════════════════════

function WelcomeHeader() {
  return (
    <div>
      <h1 className="text-xl font-bold" style={{ color: C.heading }}>
        Welcome to PayWay Sandbox, <span style={{ color: C.teal }}>Henry</span>
      </h1>
      <p className="text-sm mt-1" style={{ color: C.bodyGrey }}>
        Complete your setup and run your first test transaction in a secure Sandbox environment.
      </p>
    </div>
  );
}

function QuickAccessCards({ onCreateTx }: { onCreateTx: () => void }) {
  const cards = [
    { icon: <KeyIcon16 />,     label: "API Credentials",   desc: "View and copy your sandbox keys", color: C.teal,     bg: C.tealBg,  onClick: undefined },
    { icon: <ListCheckIcon />, label: "Quick Start Guide",  desc: "Set up in 5 steps",               color: "#8B5CF6",  bg: "#F3F0FF",  onClick: undefined },
    { icon: <CardIcon />,      label: "Test Payment",       desc: "Run a test transaction now",      color: "#F59E0B",  bg: "#FFFBEB",  onClick: onCreateTx },
    { icon: <ActivityIcon />,  label: "Transaction Logs",   desc: "View all API activity",           color: "#10B981",  bg: "#ECFDF5",  onClick: undefined },
  ];
  return (
    <div className="grid grid-cols-4 gap-4">
      {cards.map(card => (
        <button
          key={card.label}
          onClick={card.onClick}
          className="bg-white rounded-lg border border-gray-100 shadow-sm p-4 text-left flex items-center gap-3.5 hover:shadow-md transition-shadow"
        >
          <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: card.bg }}>
            <div style={{ color: card.color }}>{card.icon}</div>
          </div>
          <div>
            <div className="text-sm font-semibold text-gray-800">{card.label}</div>
            <div className="text-xs text-gray-400 mt-0.5">{card.desc}</div>
          </div>
        </button>
      ))}
    </div>
  );
}

function ApiCredentials() {
  const [revealPub, setRevealPub] = useState(false);
  const [revealSec, setRevealSec] = useState(false);
  const [copied, setCopied]       = useState<string | null>(null);

  const copy = (key: string, val: string) => {
    navigator.clipboard?.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(null), 1800);
  };

  const rows = [
    { key: "pub", label: "Public Key", value: "pk_sandbox_a1b2c3d4e5f6g7h8i9j0", vis: revealPub, toggle: () => setRevealPub(v => !v) },
    { key: "sec", label: "Secret Key", value: "sk_sandbox_z9y8x7w6v5u4t3s2r1q0", vis: revealSec, toggle: () => setRevealSec(v => !v) },
  ];

  return (
    <div className="bg-white rounded-lg border border-gray-100 shadow-sm p-5 flex flex-col">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 rounded-md flex items-center justify-center" style={{ backgroundColor: C.tealBg }}>
          <KeyIcon16 style={{ color: C.teal }} />
        </div>
        <h2 className="text-sm font-semibold text-gray-700">API Credentials</h2>
      </div>
      <div className="flex flex-col divide-y divide-gray-50">
        {rows.map(row => (
          <div key={row.key} className="flex items-center gap-2.5 py-3">
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide w-20 shrink-0">{row.label}</span>
            <span
              className="flex-1 font-mono text-xs bg-gray-50 rounded px-2.5 py-2 text-gray-600 truncate"
              style={{ letterSpacing: row.vis ? "0.04em" : "0.1em" }}
            >
              {row.vis ? row.value : "•".repeat(20)}
            </span>
            <div className="relative">
              <button
                className="shrink-0 text-xs px-2.5 py-1.5 rounded-md border font-medium transition-colors"
                style={{ color: C.teal, borderColor: C.teal }}
                onClick={() => copy(row.key, row.value)}
              >
                {copied === row.key ? "Copied!" : "Copy"}
              </button>
            </div>
            <button
              className="shrink-0 text-xs px-2.5 py-1.5 rounded-md font-medium text-white"
              style={{ backgroundColor: C.teal }}
              onClick={row.toggle}
            >
              {row.vis ? "Hide" : "Reveal"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

const QS_STEPS = [
  { title: "Create your sandbox account",  desc: "Sign up and access the developer portal",       state: "done"   as const },
  { title: "Copy your API credentials",    desc: "Get your public and secret keys above",          state: "active" as const },
  { title: "Make your first API call",     desc: "Send a POST /v1/charge to test authentication",  state: "idle"   as const },
  { title: "Run your first transaction",   desc: "Simulate a real payment end-to-end",             state: "idle"   as const, cta: true },
];

function Quickstart({ onCreateTx }: { onCreateTx: () => void }) {
  return (
    <div className="bg-white rounded-lg border border-gray-100 shadow-sm p-5 flex flex-col">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-7 h-7 rounded-md flex items-center justify-center" style={{ backgroundColor: "#F3F0FF" }}>
          <ListCheckIcon style={{ color: "#8B5CF6" }} />
        </div>
        <h2 className="text-sm font-semibold text-gray-700">Quick Start Guide</h2>
      </div>
      <div className="flex flex-col gap-3.5">
        {QS_STEPS.map((step, i) => (
          <div key={i}>
            <div className="flex items-start gap-3">
              {step.state === "done" ? (
                <div className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5" style={{ backgroundColor: C.teal }}>
                  <svg width="10" height="8" fill="none" stroke="white" strokeWidth="2.5" viewBox="0 0 10 8"><polyline points="1,4 3.5,6.5 9,1"/></svg>
                </div>
              ) : step.state === "active" ? (
                <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5" style={{ borderColor: C.teal }}>
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: C.teal }} />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full border-2 border-gray-200 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <p className={`text-sm leading-snug ${step.state === "active" ? "font-semibold text-gray-800" : step.state === "done" ? "font-medium text-gray-400 line-through" : "font-medium text-gray-400"}`}>
                  {step.title}
                </p>
                <p className={`text-xs mt-0.5 ${step.state === "active" ? "text-gray-500" : "text-gray-400"}`}>
                  {step.desc}
                </p>
              </div>
            </div>
            {step.cta && (
              <button
                onClick={onCreateTx}
                className="ml-8 mt-2 text-xs font-semibold px-3 py-1.5 rounded-lg text-white"
                style={{ backgroundColor: C.teal }}
              >
                + Create Test Transaction
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function RecentApiActivity() {
  return (
    <div className="bg-white rounded-lg border border-gray-100 shadow-sm">
      <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-700">Recent API Activity</h2>
        <a href="#" className="text-xs font-medium" style={{ color: C.teal }}>View all transactions →</a>
      </div>
      <div className="grid grid-cols-3 px-6 py-2.5 bg-gray-50 border-b border-gray-100">
        {["Time", "Endpoint", "Status"].map(col => (
          <span key={col} className="text-xs font-semibold text-gray-500 uppercase tracking-wide">{col}</span>
        ))}
      </div>
      <div className="flex flex-col items-center justify-center py-12">
        <div className="flex flex-col gap-2.5 mb-4">
          <div className="h-2.5 rounded-full bg-gray-200" style={{ width: 144 }} />
          <div className="h-2.5 rounded-full bg-gray-200" style={{ width: 112 }} />
          <div className="h-2.5 rounded-full bg-gray-200" style={{ width: 128 }} />
        </div>
        <svg width="36" height="36" fill="none" stroke="#D1D5DB" strokeWidth="1.5" viewBox="0 0 24 24" className="mb-3">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
        </svg>
        <p className="text-sm font-semibold text-gray-500">No activity yet.</p>
        <p className="text-xs text-gray-400 mt-1">Make your first test call to see results here.</p>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// ROOT APP
// ═════════════════════════════════════════════════════════════════════════════

type Screen = "entry" | "dashboard";

export default function App() {
  const [screen,       setScreen]       = useState<Screen>("entry");
  const [showModal,    setShowModal]    = useState(false);
  const [tourStep,     setTourStep]     = useState<number | null>(null);
  const [showCreateTx, setShowCreateTx] = useState(false);
  const [devOpen,      setDevOpen]      = useState(true);

  const handleEnter = () => { setScreen("dashboard"); setShowModal(true); };
  const handleTour  = () => { setShowModal(false); setTourStep(0); };
  const handleNext  = () => setTourStep(prev => prev !== null && prev < TOUR_STEPS.length - 1 ? prev + 1 : null);
  const handlePrev  = () => setTourStep(prev => prev !== null && prev > 0 ? prev - 1 : prev);

  if (screen === "entry") return <EntryScreen onEnter={handleEnter} />;

  return (
    <div className="min-h-screen flex flex-col" style={{ fontFamily: "'Inter', sans-serif", minWidth: 1440 }}>
      <SandboxBanner />
      <TopNav />

      <div className="flex flex-1">
        <Sidebar devOpen={devOpen} setDevOpen={setDevOpen} />
        <main className="flex-1 flex flex-col gap-5 p-6 overflow-y-auto" style={{ backgroundColor: C.contentBg }}>
          <WelcomeHeader />
          <QuickAccessCards onCreateTx={() => setShowCreateTx(true)} />
          <div className="grid grid-cols-2 gap-5">
            <ApiCredentials />
            <Quickstart onCreateTx={() => setShowCreateTx(true)} />
          </div>
          <RecentApiActivity />
        </main>
      </div>

      {showModal && (
        <WelcomeModal
          onDismiss={() => setShowModal(false)}
          onTour={handleTour}
        />
      )}
      {tourStep !== null && (
        <TourOverlay
          step={tourStep}
          total={TOUR_STEPS.length}
          onNext={handleNext}
          onPrev={handlePrev}
          onSkip={() => setTourStep(null)}
        />
      )}
      {showCreateTx && <CreateTransactionModal onClose={() => setShowCreateTx(false)} />}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// ICONS
// ═════════════════════════════════════════════════════════════════════════════

function NavIcon({ name, active }: { name: string; active: boolean }) {
  const col = active ? C.teal : "#7A909C";
  const p   = { width: 15, height: 15, fill: "none" as const, stroke: col, strokeWidth: 1.8, viewBox: "0 0 24 24" as const };
  if (name === "home")    return <svg {...p}><path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H5a1 1 0 01-1-1V9.5z"/><path d="M9 21V12h6v9"/></svg>;
  if (name === "swap")    return <svg {...p}><path d="M7 16V4m0 0L3 8m4-4l4 4"/><path d="M17 8v12m0 0l4-4m-4 4l-4-4"/></svg>;
  if (name === "file")    return <svg {...p}><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>;
  if (name === "user")    return <svg {...p}><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
  if (name === "tag")     return <svg {...p}><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>;
  if (name === "link")    return <svg {...p}><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>;
  if (name === "key")     return <svg {...p}><circle cx="7" cy="17" r="3"/><path d="M10.5 13.5L21 3"/><path d="M18 5l2 2"/></svg>;
  if (name === "sliders") return <svg {...p}><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>;
  if (name === "book")    return <svg {...p}><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>;
  return null;
}

function KeyIcon16({ style }: { style?: React.CSSProperties }) {
  return (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" style={style}>
      <circle cx="7" cy="17" r="3"/><path d="M10.5 13.5L21 3"/><path d="M18 5l2 2"/>
    </svg>
  );
}

function ListCheckIcon({ style }: { style?: React.CSSProperties }) {
  return (
    <svg width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" style={style}>
      <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
      <polyline points="3 6 4 7 6 5"/><polyline points="3 12 4 13 6 11"/><polyline points="3 18 4 19 6 17"/>
    </svg>
  );
}

function CardIcon() {
  return (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>
    </svg>
  );
}

function ActivityIcon() {
  return (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
    </svg>
  );
}
